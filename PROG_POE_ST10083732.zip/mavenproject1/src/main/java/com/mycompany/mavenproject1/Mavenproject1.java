/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject1;

/**
 *
 * @author Computer1
 */
public class Mavenproject1 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
     private String taskName;
    private int taskId;
    private int taskDuration; // Assuming duration is in minutes
    private String taskStatus; // Assuming status is a string representation

    // Constructor
    public Mavenproject1askName, int taskId, int taskDuration, String taskStatus) {
        this.taskName = taskName;
        this.taskId = taskId;
        this.taskDuration = taskDuration;
        this.taskStatus = taskStatus;
    }

    // Getters and setters
    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public int getTaskId() {
        return taskId;
    }

    public void setTaskId(int taskId) {
        this.taskId = taskId;
    }

    public int getTaskDuration() {
        return taskDuration;
    }

    public void setTaskDuration(int taskDuration) {
        this.taskDuration = taskDuration;
    }

    public String getTaskStatus() {
        return taskStatus;
    }

    public void setTaskStatus(String taskStatus) {
        this.taskStatus = taskStatus;
    }

    public static void main(String[] args) {
        // Example array of tasks
        Task[] tasks = new Task[3];

        // Initialize tasks
        tasks[0] = new Task("Task 1", 1, 60, "Pending");
        tasks[1] = new Task("Task 2", 2, 30, "In Progress");
        tasks[2] = new Task("Task 3", 3, 120, "Completed");

        // Print out tasks
        System.out.println("Task List:");
        for (Task task : tasks) {
            System.out.println("Task Name: " + task.getTaskName());
            System.out.println("Task ID: " + task.getTaskId());
            System.out.println("Task Duration: " + task.getTaskDuration() + " minutes");
            System.out.println("Task Status: " + task.getTaskStatus());
            System.out.println();
        }
    }
}

