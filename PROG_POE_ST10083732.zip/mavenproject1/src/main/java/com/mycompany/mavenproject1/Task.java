/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author Computer1
 */
public class Task {
    private String taskName;
    private int taskId;
    private int taskDuration; // Assuming duration is in minutes
    private String taskStatus; // Assuming status is a string representation

    // Constructor
    public Task(String taskName, int taskId, int taskDuration, String taskStatus) {
        this.taskName = taskName;
        this.taskId = taskId;
        this.taskDuration = taskDuration;
        this.taskStatus = taskStatus;
    }

    // Getters and setters
    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public int getTaskId() {
        return taskId;
    }

    public void setTaskId(int taskId) {
        this.taskId = taskId;
    }

    public int getTaskDuration() {
        return taskDuration;
    }

    public void setTaskDuration(int taskDuration) {
        this.taskDuration = taskDuration;
    }

    public String getTaskStatus() {
        return taskStatus;
    }

    public void setTaskStatus(String taskStatus) {
        this.taskStatus = taskStatus;
    }
}

