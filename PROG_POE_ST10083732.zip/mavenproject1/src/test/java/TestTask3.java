/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Computer1
 */
import org.junit.Test;
import static org.junit.Assert.*;

public class TaskTest3 {

    @Test
    public void testCreateTask() {
        // Test data
        String developer = "Glenda Oberholzer";
        String taskName = "Add Arrays";
        int taskDuration = 11; // in minutes
        String taskStatus = "To Do";

        // Create a task
        Task task = new Task(taskName, 1, taskDuration, taskStatus);

        // Assertions to verify task details
        assertEquals(taskName, task.getTaskName());
        assertEquals(taskDuration, task.getTaskDuration());
        assertEquals(taskStatus, task.getTaskStatus());
        // Assuming taskId is auto-generated or managed elsewhere,
        // you might want to assert other properties depending on your requirements.
    }
}

